repeat task.wait() until game:IsLoaded()

local startTick = tick()

local request = (syn and syn.request) or request or http_request or (http and http.request)
local queueteleport = syn and syn.queue_on_teleport or queue_on_teleport or fluxus and fluxus.queue_on_teleport
local setthreadidentityfunc = syn and syn.set_thread_identity or set_thread_identity or setidentity or setthreadidentity
local getthreadidentityfunc = syn and syn.get_thread_identity or get_thread_identity or getidentity or getthreadidentity

--Services
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local input = game:GetService("UserInputService")
local Players = game:GetService("Players")
local CoreGui = game:GetService("CoreGui")

--Instances
local LocalPlayer = Players.LocalPlayer
local Character = LocalPlayer.Character
local HumanoidRootPart = Character.HumanoidRootPart
local Humanoid = Character.Humanoid
local Camera = workspace.CurrentCamera
local RealCamera = workspace.Camera
local Mouse = LocalPlayer:GetMouse()
local PlayerGui = LocalPlayer.PlayerGui

-- Mana instances
local entity = Mana.Entity
local GuiLibrary = Mana.GuiLibrary
local Tabs = Mana.Tabs
local Functions = Mana.funcs

--What do i write here
local getasset = getsynasset or getcustomasset

do
    local highjump
    local highjumpforce = {["Value"] = 20}
    highjump = Tabs["Blatant"]:CreateToggle({
        ["Name"] = "HighJump",
        ["Keybind"] = nil,
        ["Callback"] = function(v)
            local highjumpval = v
            if highjumpval then
                LocalPlayer.Character.Humanoid:ChangeState("Jumping")
                task.wait()
                workspace.Gravity = 5
                spawn(function()
                    for i = 1, highjumpforce["Value"] do
                        wait()
                        if (not highjumpval) then return end
                        LocalPlayer.Character.Humanoid:ChangeState("Jumping")
                    end
                end)
                spawn(function()
                    for i = 1, highjumpforce["Value"] / 28 do
                        task.wait(0.1)
                        LocalPlayer.Character.Humanoid:ChangeState(Enum.HumanoidStateType.Freefall)
                        task.wait(0.1)
                        LocalPlayer.Character.Humanoid:ChangeState(Enum.HumanoidStateType.Jumping)
                    end
                end)
                highjump:silentToggle()
            else
                workspace.Gravity = 196.19999694824
                return
            end
        end
    })
    highjumpforce = highjump:CreateSlider({
        ["Name"] = "Force",
        ["Function"] = function() end,
        ["Min"] = 0,
        ["Max"] = 50,
        ["Default"] = 25,
        ["Round"] = 0
    })
end

Speedeb = {["Value"] = 23}

do
    local longjumpval = false
    local gravityval = {["Value"] = 0}
    local longjumpdelay = {["Value"] = 0.1}
    local LJSpeed = {["Value"] = 100}
    local oldthing
    local lognjump = Tabs["Blatant"]:CreateToggle({
        ["Name"] = "LongJump",
        ["Keybind"] = nil,
        ["Callback"] = function(v)
            longjumpval = v
            if longjumpval then
                oldthing = oldthing or Speedeb["Value"]
                workspace.Gravity = gravityval["Value"]
                repeat
                    if (not longjumpval) then break end
                    --Speedeb["Value"] = LJSpeed["Value"]
                    task.wait(longjumpdelay["Value"])
                   -- Speedeb["Value"] = oldthing
                    task.wait(0.12)
                until (not longjumpval)
            else
                workspace.Gravity = 196.19999694824
                --speedvalue["Value"] = oldthing
                return
            end
        end
    })
    gravityval = lognjump:CreateSlider({
        ["Name"] = "Gravity",
        ["Function"] = function() end,
        ["Min"] = 0,
        ["Max"] = 10,
        ["Default"] = 0,
        ["Round"] = 0
    })
    longjumpdelay = lognjump:CreateSlider({
        ["Name"] = "Delay",
        ["Function"] = function() end,
        ["Min"] = 0,
        ["Max"] = 1,
        ["Default"] = 0.1,
        ["Round"] = 1
    })
    LJSpeed = lognjump:CreateSlider({
        ["Name"] = "Speed",
        ["Function"] = function() end,
        ["Min"] = 0,
        ["Max"] = 100,
        ["Default"] = 23,
        ["Round"] = 0
    })
end

do
    local customlongjumpval = false
    local LongJumpV2Gravity = {["Value"] = 23}
local LongJumpV2 = Tabs["Blatant"]:CreateToggle({
        ["Name"] = "LongJumpV2",
        ["Keybind"] = nil,
        ["Callback"] = function(v)
            customlongjumpval = v
            if customlongjumpval then
                spawn(function()
                    repeat
                        if (not customlongjumpval) then return end
                        task.wait()
                        if LocalPlayer.Character.Humanoid.Jump == true then
                            if (not customlongjumpval) then return end
                            LocalPlayer.Character.Humanoid.WalkSpeed = 15
                            Workspace.Gravity = 23
                            LocalPlayer.Character.HumanoidRootPart.CFrame = LocalPlayer.Character.HumanoidRootPart.CFrame * CFrame.new(0,-0.2,-2.1) 
                            wait(0.1)
                            LocalPlayer.Character.HumanoidRootPart.CFrame = LocalPlayer.Character.HumanoidRootPart.CFrame * CFrame.new(0,-0.5,-2.1) 
                            wait(0.1)
                            LocalPlayer.Character.HumanoidRootPart.CFrame = LocalPlayer.Character.HumanoidRootPart.CFrame * CFrame.new(0, 0.2 ,0) 
                            wait(0.1)
                        end
                    until (not customlongjumpval)                
                end)
                spawn(function()
                    repeat
                        if (not customlongjumpval) then return end
                        LocalPlayer.Character.Humanoid:ChangeState(Enum.HumanoidStateType.Freefall)
                        wait()
                        LocalPlayer.Character.Humanoid:ChangeState(Enum.HumanoidStateType.Running)
                        wait()
                        LocalPlayer.Character.Humanoid:ChangeState(Enum.HumanoidStateType.Landed)
                        wait()
                    until (not customlongjumpval)
                end)
            else
                workspace.Gravity = 196.19999694824
                return
            end
        end
    })
    
    LongJumpV2Gravity = LongJumpV2:CreateSlider({
        ["Name"] = "Gravity",
        ["Function"] = function() end,
        ["Min"] = 0,
        ["Max"] = 23,
        ["Default"] = 1,
        ["Round"] = 0
    })
end



SpeedobBeb = Tabs["Blatant"]:CreateToggle({
    ["Name"] = "Speed",
    ["Keybind"] = nil,
    ["Callback"] = function(v)
        if v == true then
             game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = Speedeb["Value"]
             --game.Players.LocalPlayer.Character.Humanoid.JumpPower = jumpbeb["Value"]
        else
             game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = 16
             game.Players.LocalPlayer.Character.Humanoid.JumpPower = 23
        end
    end
})

Speedeb = SpeedobBeb:CreateSlider({
        ["Name"] = "Speed",
        ["Function"] = function()
        game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = Speedeb["Value"]
        end,
        ["Min"] = 0,
        ["Max"] = 23,
        ["Default"] = 23,
        ["Round"] = 0
    })



local flygravityb = {Value = 0}
local flyspeedb = {Value = 23}
local FlyStudTP = {Value = 5}
local flyenabled = false

local function flyLogic()
    if not flyenabled then
        return
    end
    
    local player = game.Players.LocalPlayer
    local character = player.Character
    if not character or not character:IsDescendantOf(workspace) then
        return
    end
    
    local humanoid = character:FindFirstChild("Humanoid")
    if not humanoid or humanoid.Health == 0 then
        return
    end
    
    local HumanoidRootPart = character:FindFirstChild("HumanoidRootPart")
    if not HumanoidRootPart then
        return
    end
    
    workspace.Gravity = flygravityb.Value
    humanoid.WalkSpeed = flyspeedb.Value
    
    local UserInputService = game:GetService("UserInputService")
    local SpaceHeld = UserInputService:IsKeyDown(Enum.KeyCode.Space)
    local ShiftHeld = UserInputService:IsKeyDown(Enum.KeyCode.LeftShift)
    
    if SpaceHeld then
        HumanoidRootPart.CFrame = HumanoidRootPart.CFrame * CFrame.new(0, FlyStudTP.Value, 0)
    end
    
    if ShiftHeld then
        HumanoidRootPart.CFrame = HumanoidRootPart.CFrame * CFrame.new(0, -FlyStudTP.Value, 0)
    end
end

local fly = Tabs["Blatant"]:CreateToggle({
    Name = "Fly",
    Keybind = nil,
    Callback = function(v)
        flyenabled = v
        
        if flyenabled then
            spawn(function()
                while flyenabled do
                    flyLogic()
                    wait()
                end
            end)
        else
            local player = game.Players.LocalPlayer
            if player.Character then
                player.Character.Humanoid.WalkSpeed = flyspeedb.Value
            end
            workspace.Gravity = 196
        end
    end
})

flyspeedb = fly:CreateSlider({
    Name = "FlyWalkSpeed",
    Function = function(v)
        if flyenabled then
            game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = v
        end
    end,
    Min = 0,
    Max = 23,
    Default = 23,
    Round = 0
})

flygravityb = fly:CreateSlider({
    Name = "FlyGravity",
    Function = function(v)
        if flyenabled then
            workspace.Gravity = v
        end
    end,
    Min = 0,
    Max = 196,
    Default = 0,
    Round = 0
})

FlyStudTP = fly:CreateSlider({
    Name = "StudTP",
    Function = function(v)
    end,
    Min = 0,
    Max = 15,
    Default = 5,
    Round = 0
})



local flightenabled
local flyght = Tabs["Blatant"]:CreateToggle({
        ["Name"] = "Flight",
        ["Keybind"] = nil,
        ["Callback"] = function(v)
            if v then
                spawn(function()
                    repeat
                        task.wait()
                        workspace.Gravity = 0
                    until (not flyenabled == true)
                end)
            else
                workspace.Gravity = 196
            end
        end
    })
local colorbox
local function makeRainbowText(text)
    spawn(function()
        colorbox = Color3.fromRGB(170,0,170)
        local x = 0
        while wait() do
            colorbox = Color3.fromHSV(x,1,1)
            x = x + 4.5/255
            if x >= 1 then
                x = 0
            end
        end
    end)
    spawn(function()
        repeat
            wait()
            text.TextColor3 = colorbox
        until true == false
    end)
end

local colorboxsecond
local function makeRainbowBackground(text)
    spawn(function()
        colorboxsecond = Color3.fromRGB(170,0,170)
        local x = 0
        while wait(0.1) do
            colorboxsecond = Color3.fromHSV(x,1,1)
            x = x + 4.5/255
            if x >= 1 then
                x = 0
            end
        end
    end)
    spawn(function()
        repeat
            wait()
            text.BackgroundColor3 = colorboxsecond
        until true == false
    end)
end

local ESPFolder
Tabs["Render"]:CreateToggle({
    ["Name"] = "ESP",
    ["Keybind"] = nil,
    ["Callback"] = function(v)
        local thing
        local espval = v
        if espval then
            spawn(function()
                ESPFolder = Instance.new("Folder")
                ESPFolder.Name = "ESPFolder"
                ESPFolder.Parent = ScreenGuitwo
                repeat
                    task.wait()
                    if (not espval) then break end
                    for i,plr in pairs(game.Players:GetChildren()) do
                        if ESPFolder:FindFirstChild(plr.Name) then
                            thing = ESPFolder[plr.Name]
                            thing.Visible = false
                        else
                            thing = Instance.new("ImageLabel")
                            thing.BackgroundTransparency = 0
                            thing.BorderSizePixel = 0
                            thing.Image = 4818709366
                            thing.Visible = true
                            thing.Name = plr.Name
                            thing.Parent = ESPFolder
                            thing.Size = UDim2.new(0, 256, 0, 256)
                        end
                        
                        if isAlive(plr) and plr ~= LocalPlayer and plr.Team ~= tostring(LocalPlayer.Team) then
                            local rootPos, rootVis = Camera:WorldToViewportPoint(plr.Character.HumanoidRootPart.Position)
                            local rootSize = (plr.Character.HumanoidRootPart.Size.X * 1200) * (Camera.ViewportSize.X / 1920)
                            local headPos, headVis = Camera:WorldToViewportPoint(plr.Character.HumanoidRootPart.Position + Vector3.new(0, 1 + (plr.Character.Humanoid.RigType == Enum.HumanoidRigType.R6 and 2 or plr.Character.Humanoid.HipHeight), 0))
                            local legPos, legVis = Camera:WorldToViewportPoint(plr.Character.HumanoidRootPart.Position - Vector3.new(0, 1 + (plr.Character.Humanoid.RigType == Enum.HumanoidRigType.R6 and 2 or plr.Character.Humanoid.HipHeight), 0))
                            rootPos = rootPos
                            if rootVis then
                                thing.Visible = rootVis
                                thing.Size = UDim2.new(0, rootSize / rootPos.Z, 0, headPos.Y - legPos.Y)
                                thing.Position = UDim2.new(0, rootPos.X - thing.Size.X.Offset / 2, 0, (rootPos.Y - thing.Size.Y.Offset / 2) - 36)
                            end
                        end
                    end
                until (not espval)
            end)
            game.Players.PlayerRemoving:connect(function(plr)
                if ESPFolder:FindFirstChild(plr.Name) then
                    ESPFolder[plr.Name]:Remove()
                end
            end)
        else
            ESPFolder:remove()
            return
        end
    end
})


local chinahattrail
local chinahatenabled = false
Tabs["Render"]:CreateToggle({
    ["Name"] = "ChinaHat",
    ["Keybind"] = nil,
    ["Callback"] = function(v)
        chinahatenabled = v
        if chinahatenabled then
			spawn(function()
                repeat
                    task.wait(0.3)
                    if (not chinahatenabled) then return end
                    if entity.isAlive then
                        if chinahattrail == nil or chinahattrail.Parent == nil then
                            chinahattrail = Instance.new("Part")
                            chinahattrail.CFrame = LocalPlayer.Character.Head.CFrame * CFrame.new(0, 1.1, 0)
                            chinahattrail.Size = Vector3.new(3, 0.7, 3)
                            chinahattrail.Name = "ChinaHat"
                            chinahattrail.Material = Enum.Material.Neon
                            chinahattrail.CanCollide = false
                            chinahattrail.Transparency = 0.3
                            local chinahatmesh = Instance.new("SpecialMesh")
                            chinahatmesh.Parent = chinahattrail
                            chinahatmesh.MeshType = "FileMesh"
                            chinahatmesh.MeshId = "http://www.roblox.com/asset/?id=1778999"
                            chinahatmesh.Scale = Vector3.new(3, 0.6, 3)
                            local chinahatweld = Instance.new("WeldConstraint")
                            chinahatweld.Name = "WeldConstraint"
                            chinahatweld.Parent = chinahattrail
                            chinahatweld.Part0 = LocalPlayer.Character.Head
                            chinahatweld.Part1 = chinahattrail
                            chinahattrail.Parent = RealCamera
                        else
                            chinahattrail.Parent = RealCamera
                            chinahattrail.CFrame = LocalPlayer.Character.Head.CFrame * CFrame.new(0, 1.1, 0)
                            chinahattrail.LocalTransparencyModifier = ((Camera.CFrame.Position - Camera.Focus.Position).Magnitude <= 0.6 and 1 or 0)
                            if chinahattrail:FindFirstChild("WeldConstraint") then
                                chinahattrail.WeldConstraint.Part0 = LocalPlayer.Character.Head
                            end
                        end
                    else
                        if chinahattrail then 
                            chinahattrail:remove()
                            chinahattrail = nil
                        end
                    end
                until (not chinahatenabled)
            end)
        else
            if chinahattrail then
                chinahattrail:Remove()
                chinahattrail = nil
            end
        end
    end
})

local antivoidpart
local antivoidparttransparency = {Value = 0}
local AntiVoidJumpDelay = {Value = 0.2}
local AntiVoid = Tabs["World"]:CreateToggle({
    ["Name"] = "AntiVoid",
    ["Keybind"] = nil,
    ["Callback"] = function(v)
        if v then
            local antivoidpart = Instance.new("Part", Workspace)
            antivoidpart.Name = "AntiVoid"
            antivoidpart.Size = Vector3.new(2100, 0.5, 2000)
            antivoidpart.Position = Vector3.new(160.5, 25, 247.5)
            antivoidpart.Transparency = antivoidparttransparency.Value
            antivoidpart.Anchored = true
            antivoidpart.Touched:connect(function(thing)
                if thing.Parent:WaitForChild("Humanoid") and thing.Parent.Name == LocalPlayer.Name then
                    game.Players.LocalPlayer.Character.Humanoid:ChangeState("Jumping")
                    wait(AntiVoidJumpDelay.Value)
                    game.Players.LocalPlayer.Character.Humanoid:ChangeState("Jumping")
                    wait(AntiVoidJumpDelay.Value)
                    game.Players.LocalPlayer.Character.Humanoid:ChangeState("Jumping")
                end
            end)
        else
            game.Workspace.AntiVoid:remove()
        end
    end
})
    antivoidparttransparency = AntiVoid:CreateSlider({
        ["Name"] = "Part Transparency",
        ["Function"] = function(a)
            if v then
            game.Workspace.AntiVoid.Transparency = a
            end
        end,
        ["Min"] = 0,
        ["Max"] = 1,
        ["Default"] = 0,
        ["Round"] = 1
    })
    JumpDelay = AntiVoid:CreateSlider({
        ["Name"] = "JumpDelay",
        ["Function"] = function() end,
        ["Min"] = 0,
        ["Max"] = 5,
        ["Default"] = 0.2,
        ["Round"] = 1
    })


local GravityValueBeb = {["Value"] = 18}
local gravBeb = Tabs["World"]:CreateToggle({
    ["Name"] = "Gravity",
    ["Keybind"] = nil,
    ["Callback"] = function(v)
        if v == true then
            workspace.Gravity = GravityValueBeb["Value"]
        else
            workspace.Gravity = 196.19999694824
        end
    end
})
GravityValueBeb = gravBeb:CreateSlider({
        ["Name"] = "Gravity",
        ["Function"] = function()
        workspace.Gravity = GravityValueBeb["Value"]
        end,
        ["Min"] = 1,
        ["Max"] = 200,
        ["Default"] = 196,
        ["Round"] = 0
    })

local Hours = {["Value"] = 13}
local Minutes = {["Value"] = 0}
local Seconds = {["Value"] = 0}

TimeOfDay = Tabs["Render"]:CreateToggle({
    ["Name"] = "TimeOfDay",
    ["Keybind"] = nil,
    ["Callback"] = function(v)
        if v == true then
             game.Lighting.TimeOfDay = Hours["Value"]..":"..Minutes["Value"]..":"..Seconds["Value"]
        else
             game.Lighting.TimeOfDay = "13:00:00"
        end
    end
})
    
    Hours = TimeOfDay:CreateSlider({
        ["Name"] = "Hours",
        ["Function"] = function()
        game.Lighting.TimeOfDay = Hours["Value"]..":"..Minutes["Value"]..":"..Seconds["Value"]
        end,
        ["Min"] = 0,
        ["Max"] = 24,
        ["Default"] = 13,
        ["Round"] = 0
    })
    
    Minutes = TimeOfDay:CreateSlider({
        ["Name"] = "Minutes",
        ["Function"] = function()
        game.Lighting.TimeOfDay = Hours["Value"]..":"..Minutes["Value"]..":"..Seconds["Value"]
        end,
        ["Min"] = 0,
        ["Max"] = 64,
        ["Default"] = 0,
        ["Round"] = 0
    })
    
    Seconds = TimeOfDay:CreateSlider({
        ["Name"] = "Seconds",
        ["Function"] = function()
        game.Lighting.TimeOfDay = Hours["Value"]..":"..Minutes["Value"]..":"..Seconds["Value"]
        end,
        ["Min"] = 0,
        ["Max"] = 64,
        ["Default"] = 0,
        ["Round"] = 0
    })

Tabs["Render"]:CreateToggle({
    ["Name"] = "HP",
    ["Keybind"] = nil,
    ["Callback"] = function(v)
        if v == true then
            screenien = Instance.new("ScreenGui", game:GetService("CoreGui"))
			Background = Instance.new("Frame")
			Text = Instance.new("TextLabel")
			UICorner = Instance.new("UICorner")
			Dragg = Instance.new("TextLabel")
			ICorner_2 = Instance.new("UICorner")
			
			
			screenien.Name = ("54674679857")
			
			Background.Name = "Background"
			Background.Parent = screenien
			Background.BackgroundColor3 = Color3.fromRGB(83, 83, 83)
			Background.BackgroundTransparency = 1.000
			Background.Position = UDim2.new(0.0220729373, 0, 0.0688000023, 0)
			Background.Size = UDim2.new(0, 100, 0, 40)
			Background.Draggable = true
			Background.Active = true
			Background.Selectable = true
			
			Text.Name = "Text"
			Text.Parent = Background
			Text.BackgroundColor3 = Color3.fromRGB(81, 81, 81)
			Text.BackgroundTransparency = 0.500
			Text.BorderSizePixel = 0
			Text.Position = UDim2.new(0.400000006, 0, 0, 0)
			Text.Size = UDim2.new(0, 60, 0, 40)
			Text.Font = Enum.Font.Gotham
			
			Text.TextColor3 = Color3.fromRGB(255, 255, 255)
			Text.TextSize = 20.000
			
			UICorner.CornerRadius = UDim.new(0, 3)
			UICorner.Parent = Text
			
			Dragg.Name = "Dragg"
			Dragg.Parent = Background
			Dragg.BackgroundColor3 = Color3.fromRGB(141, 255, 121)
			Dragg.BackgroundTransparency = 0.500
			Dragg.BorderSizePixel = 0
			Dragg.Position = UDim2.new(0.0599999987, 0, 0, 0)
			Dragg.Size = UDim2.new(0, 35, 0, 40)
			Dragg.Font = Enum.Font.SourceSans
			Dragg.Text = ""
			Dragg.TextColor3 = Color3.fromRGB(0, 0, 0)
			Dragg.TextSize = 14.000
			
			while wait(0.1) do
			Text.Text = game.Players.LocalPlayer.character.Humanoid.Health
			end
        else
             screenien:Destroy()
        end
    end
})

local TPValue = {Value = 5}
local isTeleporting = false

local AntiRusher = Tabs["Utility"]:CreateToggle({
    Name = "ForwardTP",
    Keybind = nil,
    Callback = function(v)
        if v and not isTeleporting then
            isTeleporting = true
            local player = game.Players.LocalPlayer
            local character = player.Character
            if character then
                local humanoid = character.Humanoid
                if humanoid.MoveDirection.Magnitude > 0 or humanoid:GetState() == Enum.HumanoidStateType.Running then
                    local forwardVector = character.HumanoidRootPart.CFrame.lookVector
                    character.HumanoidRootPart.CFrame = character.HumanoidRootPart.CFrame + forwardVector * TPValue.Value
                end
            end
            isTeleporting = false
            else
            
        end
    end
})

TPValue = AntiRusher:CreateSlider({
    Name = "Studs",
    Function = function(v)
        TPValue.Value = v
    end,
    Min = 0,
    Max = 50,
    Default = 5,
    Round = 0
})

do
local OldFov = game.Workspace.Camera.FieldOfView
local NewFov = {["Value"] = 80}
local FovChanger = Tabs["Render"]:CreateToggle({
    ["Name"] = "FovChanger",
    ["Keybind"] = nil,
    ["Callback"] = function(v)
        if v then
	        Camera.FieldOfView = NewFov["Value"]
        else
            Camera.FieldOfView = OldFov
        end
    end
})

NewFov = FovChanger:CreateSlider({
        ["Name"] = "Field Of View",
        ["Function"] = function(v)
        Camera.FieldOfView = v or NewFov["Value"]
        end,
        ["Min"] = 1,
        ["Max"] = 150,
        ["Default"] = 80,
        ["Round"] = 0
    })

end

--[[
do
   -- local sayinchat = {["Value"] = false}
    local notificationsenabled = {["Value"] = true}
    local autoreport = false
    local autoreportthingy = Tabs["Utility"]:CreateToggle({
        ["Name"] = "AutoReport",
        ["Keybind"] = nil,
        ["Callback"] = function(v)
            autoreport = v
            if autoreport then
                local reporttable = {
                    ["ez"] = "Bullying",
                    ["gay"] = "Bullying",
                    ["gae"] = "Bullying",
                    ["hacks"] = "Scamming",
                    ["hacker"] = "Scamming",
                    ["hack"] = "Scamming",
                    ["cheat"] = "Scamming",
                    ["hecker"] = "Scamming",
                    ["get a life"] = "Bullying",
                    ["L"] = "Bullying",
                    ["thuck"] = "Swearing",
                    ["thuc"] = "Swearing",
                    ["thuk"] = "Swearing",
                    ["fatherless"] = "Bullying",
                    ["yt"] = "Offsite Links",
                    ["discord"] = "Offsite Links",
                    ["dizcourde"] = "Offsite Links",
                    ["retard"] = "Swearing",
                    ["tiktok"] = "Offsite Links",
                    ["bad"] = "Bullying",
                    ["trash"] = "Bullying",
                    ["die"] = "Bullying",
                    ["lobby"] = "Bullying",
                    ["ban"] = "Bullying",
                    ["youtube"] = "Offsite Links",
                    ["im hacking"] = "Cheating/Exploiting",
                    ["I'm hacking"] = "Cheating/Exploiting",
                    ["download"] = "Offsite Links",
                    ["kill your"] = "Bullying",
                    ["kys"] = "Bullying",
                    ["hack to win"] = "Bullying",
                    ["bozo"] = "Bullying",
                    ["kid"] = "Bullying",
                    ["adopted"] = "Bullying",
                    ["vxpe"] = "Cheating/Exploiting",
                    ["futureclient"] = "Cheating/Exploiting",
                    ["nova6"] = "Cheating/Exploiting",
                    [".gg"] = "Offsite Links",
                    ["gg"] = "Offsite Links",
                    ["lol"] = "Bullying",
                    ["suck"] = "Dating",
                    ["love"] = "Dating",
                    ["fuck"] = "Swearing",
                    ["sthu"] = "Swearing",
                    ["i hack"] = "Cheating/Exploiting",
                    ["disco"] = "Offsite Links",
                    ["dc"] = "Offsite Links"
                }
                function getreport(msg)
                    for i,v in pairs(reporttable) do 
                        if msg:lower():find(i) then 
                            return v
                        end
                    end
                    return nil
                end
                for i, v in pairs(game.Players:GetPlayers()) do
                    if v.Name ~= LocalPlayer.Name then
                        v.Chatted:connect(function(msg)
                            local reportfound = getreport(msg)
                            if reportfound then
                            
                                if sayinchat["Value"] then
                                    game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer("Reported " .. v.Name .. " for " .. reportfound, 'All')
                                end
                                
                                game.Players:ReportAbuse(v, reportfound, 'He said "' .. msg .. '", was very offensive to me')
                                if notificationsenabled["Value"] then
                                    print("Reported" .. v.Name, "for saying " .. msg)
                                    lib:CreateNotification("Reported" .. v.Name, "for saying " .. msg, 5, true)
                                end
                            end
                        end)
                    end
                end
            end
        end
    })
    sayinchat = autoreportthingy:CreateOptionTog({
        ["Name"] = "Say reports in chat",
        ["Default"] = false,
        ["Func"] = function() end
    })
    
    notificationsenabled = autoreportthingy:CreateOptionTog({
        ["Name"] = "Notifications",
        ["Default"] = true,
        ["Func"] = function() end
    })
end
]]
Mana.GuiLibrary:CreateNotification("Mana", "Press a button on left top of screen to toggle UI" , 10, true)
Mana.GuiLibrary:CreateUIToggleButton()

print("[Mana/Scripts/Universal.lua]: Loaded in " .. tostring(tick() - startTick) .. ".")
